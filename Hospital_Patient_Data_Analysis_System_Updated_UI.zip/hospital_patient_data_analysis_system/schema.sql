CREATE DATABASE IF NOT EXISTS hospital_analytics;
USE hospital_analytics;

CREATE TABLE IF NOT EXISTS patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    age_band VARCHAR(20) NOT NULL,
    gender VARCHAR(20) NULL,
    CHECK (age_band IN ('0-17', '18-29', '30-44', '45-59', '60+'))
);

CREATE TABLE IF NOT EXISTS departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS visits (
    visit_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    department_id INT NOT NULL,
    visit_date DATE NOT NULL,
    visit_type VARCHAR(20) NOT NULL,
    CONSTRAINT fk_visit_patient FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    CONSTRAINT fk_visit_department FOREIGN KEY (department_id) REFERENCES departments(department_id),
    CHECK (visit_type IN ('Outpatient', 'Inpatient', 'Emergency', 'Follow-up'))
);

INSERT IGNORE INTO departments (department_name) VALUES
('General Medicine'), ('Pediatrics'), ('Cardiology'), ('Orthopedics'), ('Dermatology');

-- Entirely synthetic demonstration records; no real patient identities.
INSERT INTO patients (age_band, gender) VALUES
('18-29','Female'), ('30-44','Male'), ('45-59','Female'), ('0-17','Male'),
('60+','Female'), ('30-44','Female'), ('18-29','Male'), ('45-59','Male'),
('60+','Male'), ('0-17','Female');

INSERT INTO visits (patient_id, department_id, visit_date, visit_type) VALUES
(1,1,'2026-09-02','Outpatient'), (2,3,'2026-09-03','Follow-up'),
(3,2,'2026-09-05','Outpatient'), (4,2,'2026-09-08','Outpatient'),
(5,3,'2026-09-12','Inpatient'), (6,5,'2026-09-15','Outpatient'),
(7,1,'2026-10-01','Follow-up'), (8,4,'2026-10-03','Outpatient'),
(9,3,'2026-10-06','Inpatient'), (10,2,'2026-10-09','Outpatient'),
(1,5,'2026-10-12','Follow-up'), (2,1,'2026-10-15','Outpatient'),
(3,4,'2026-10-18','Follow-up'), (5,3,'2026-10-20','Outpatient'),
(6,1,'2026-10-22','Outpatient');
