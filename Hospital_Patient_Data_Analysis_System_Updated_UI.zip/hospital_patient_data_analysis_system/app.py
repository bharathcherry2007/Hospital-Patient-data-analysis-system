import os
from datetime import date
from flask import Flask, render_template, request, redirect, url_for, flash
import mysql.connector
from mysql.connector import Error
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-this-local-demo-key")

def get_connection():
    return mysql.connector.connect(
        host=os.getenv("DB_HOST", "localhost"),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "hospital_analytics")
    )

def fetch_dataframe(query, params=None):
    conn = get_connection()
    try:
        return pd.read_sql(query, conn, params=params)
    finally:
        conn.close()

@app.route("/")
def dashboard():
    try:
        visits = fetch_dataframe("""
            SELECT v.visit_id, v.visit_date, v.visit_type, p.patient_id,
                   p.age_band, p.gender, d.department_name
            FROM visits v
            JOIN patients p ON p.patient_id = v.patient_id
            JOIN departments d ON d.department_id = v.department_id
            ORDER BY v.visit_date DESC
        """)
        total_visits = int(len(visits))
        departments = int(visits["department_name"].nunique()) if not visits.empty else 0
        unique_patients = int(visits["patient_id"].nunique()) if not visits.empty else 0
        month_visits = 0
        if not visits.empty:
            visits["visit_date"] = pd.to_datetime(visits["visit_date"])
            current_month = pd.Timestamp.today().to_period("M")
            month_visits = int((visits["visit_date"].dt.to_period("M") == current_month).sum())
        return render_template("dashboard.html", total_visits=total_visits,
                               departments=departments, unique_patients=unique_patients,
                               month_visits=month_visits, recent=visits.head(10).to_dict("records"))
    except Error as exc:
        return render_template("error.html", message=str(exc)), 500

@app.route("/visits")
def list_visits():
    try:
        df = fetch_dataframe("""
            SELECT v.visit_id, v.visit_date, v.visit_type, p.patient_id,
                   p.age_band, p.gender, d.department_name
            FROM visits v JOIN patients p ON p.patient_id=v.patient_id
            JOIN departments d ON d.department_id=v.department_id
            ORDER BY v.visit_date DESC
        """)
        return render_template("visits.html", visits=df.to_dict("records"))
    except Error as exc:
        return render_template("error.html", message=str(exc)), 500

@app.route("/visits/add", methods=["GET", "POST"])
def add_visit():
    if request.method == "POST":
        try:
            patient_id = int(request.form["patient_id"])
            department_id = int(request.form["department_id"])
            visit_date = date.fromisoformat(request.form["visit_date"])
            visit_type = request.form["visit_type"].strip()
            if visit_type not in {"Outpatient", "Inpatient", "Emergency", "Follow-up"}:
                raise ValueError("Choose a valid visit type.")
            conn = get_connection()
            try:
                cur = conn.cursor()
                cur.execute("""INSERT INTO visits (patient_id, department_id, visit_date, visit_type)
                               VALUES (%s, %s, %s, %s)""",
                            (patient_id, department_id, visit_date, visit_type))
                conn.commit()
            finally:
                conn.close()
            flash("Visit record added.", "success")
            return redirect(url_for("list_visits"))
        except (ValueError, KeyError) as exc:
            flash(f"Invalid input: {exc}", "error")
        except Error as exc:
            flash(f"Database error: {exc}", "error")
    try:
        patients = fetch_dataframe("SELECT patient_id, age_band FROM patients ORDER BY patient_id")
        departments = fetch_dataframe("SELECT department_id, department_name FROM departments ORDER BY department_name")
        return render_template("add_visit.html", patients=patients.to_dict("records"),
                               departments=departments.to_dict("records"), today=date.today().isoformat())
    except Error as exc:
        return render_template("error.html", message=str(exc)), 500

@app.route("/reports")
def reports():
    try:
        dept = fetch_dataframe("""
            SELECT d.department_name, COUNT(*) AS visit_count
            FROM visits v JOIN departments d ON d.department_id=v.department_id
            GROUP BY d.department_id, d.department_name ORDER BY visit_count DESC
        """)
        monthly = fetch_dataframe("""
            SELECT DATE_FORMAT(visit_date, '%Y-%m') AS month, COUNT(*) AS visit_count
            FROM visits GROUP BY DATE_FORMAT(visit_date, '%Y-%m') ORDER BY month
        """)
        ages = fetch_dataframe("""
            SELECT p.age_band, COUNT(*) AS visit_count
            FROM visits v JOIN patients p ON p.patient_id=v.patient_id
            GROUP BY p.age_band ORDER BY p.age_band
        """)
        os.makedirs("static/charts", exist_ok=True)
        if not dept.empty:
            plt.figure(figsize=(8, 4))
            plt.bar(dept["department_name"], dept["visit_count"])
            plt.title("Department-wise Patient Visits")
            plt.xlabel("Department"); plt.ylabel("Number of visits")
            plt.xticks(rotation=25, ha="right"); plt.tight_layout()
            plt.savefig("static/charts/departments.png", dpi=140); plt.close()
        if not monthly.empty:
            plt.figure(figsize=(8, 4))
            plt.plot(monthly["month"], monthly["visit_count"], marker="o")
            plt.title("Monthly Patient Visit Trend")
            plt.xlabel("Month"); plt.ylabel("Number of visits")
            plt.xticks(rotation=25, ha="right"); plt.tight_layout()
            plt.savefig("static/charts/monthly.png", dpi=140); plt.close()
        if not ages.empty:
            plt.figure(figsize=(7, 4))
            plt.bar(ages["age_band"], ages["visit_count"])
            plt.title("Visits by Patient Age Band")
            plt.xlabel("Age band"); plt.ylabel("Number of visits")
            plt.tight_layout(); plt.savefig("static/charts/age_bands.png", dpi=140); plt.close()
        stats = {
            "average_visits_per_month": round(float(np.mean(monthly["visit_count"])), 2) if not monthly.empty else 0,
            "median_visits_per_month": float(np.median(monthly["visit_count"])) if not monthly.empty else 0,
            "departments_reported": int(dept["department_name"].nunique()) if not dept.empty else 0
        }
        return render_template("reports.html", departments=dept.to_dict("records"),
                               monthly=monthly.to_dict("records"), ages=ages.to_dict("records"), stats=stats)
    except Error as exc:
        return render_template("error.html", message=str(exc)), 500

@app.route("/api/summary")
def api_summary():
    try:
        df = fetch_dataframe("""
            SELECT d.department_name, COUNT(*) AS visits
            FROM visits v JOIN departments d ON d.department_id=v.department_id
            GROUP BY d.department_id, d.department_name ORDER BY visits DESC
        """)
        return {"department_visit_summary": df.to_dict("records")}
    except Error as exc:
        return {"error": str(exc)}, 500

if __name__ == "__main__":
    app.run(debug=True)
