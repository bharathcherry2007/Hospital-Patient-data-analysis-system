@echo off
cd /d "%~dp0"
if not exist .venv (
  echo Creating Python virtual environment...
  python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if not defined DB_HOST set DB_HOST=localhost
if not defined DB_USER set DB_USER=root
if not defined DB_NAME set DB_NAME=hospital_analytics
if not defined DB_PASSWORD (
  echo.
  echo Set your MySQL password in this CMD window first, for example:
  echo set DB_PASSWORD=your_mysql_password
  echo Then run run_windows.bat again.
  pause
  exit /b 1
)
python app.py
pause
