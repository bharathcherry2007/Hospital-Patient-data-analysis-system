# Hospital Patient Data Analysis System

Intermediate-level educational project based on the supplied Python Flask Data Analytics Projects reference.

## Features
- Dashboard with visit count, distinct patients, departments, and current-month visits
- Add and view synthetic patient visit records
- Department-wise workload report
- Monthly visit trend chart
- Age-band visit summary and chart
- Pandas aggregation and NumPy descriptive statistics
- JSON endpoint: `/api/summary`
- Parameterized SQL insert and basic input validation

## Technology
Python, Flask, MySQL, Pandas, NumPy, Matplotlib, HTML/CSS.

## Setup
1. Install Python 3.10+ and MySQL.
2. Create and seed the database:
   `mysql -u root -p < schema.sql`
3. Create a virtual environment:
   - Windows: `python -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Set environment variables from `.env.example` in your terminal. Set `DB_PASSWORD` to your local MySQL password. Do not commit secrets.
6. Run: `python app.py`
7. Open `http://127.0.0.1:5000`.

## Main routes
- `GET /` dashboard
- `GET /visits` list visit records
- `GET /visits/add` form to add a visit
- `POST /visits/add` validates and saves a visit
- `GET /reports` analytics tables and charts
- `GET /api/summary` department visit counts as JSON

## Suggested database relationship
- One patient can have many visits.
- One department can have many visits.
- Each visit belongs to one patient and one department.

## Analysis formulas
- Total visits = count of visit records.
- Department workload = count of visits grouped by department.
- Monthly visits = count of visits grouped by calendar month.
- Age-band summary = count of visits grouped by age band.
- Average monthly visits = arithmetic mean of monthly visit counts.
- Median monthly visits = median of monthly visit counts.

## Testing checklist
1. Add a visit with valid patient/department IDs and a valid date.
2. Reject a non-numeric patient or department ID.
3. Reject an unsupported visit type.
4. Try a nonexistent patient ID and confirm the foreign-key constraint prevents it.
5. Open reports with no visit rows; tables should be empty and summary values zero.
6. Check that charts match the grouped table counts.
7. Confirm `/api/summary` returns department-wise visit counts.

## Privacy and limitations
Use only synthetic or properly de-identified data. Do not upload real patient identifiers or unnecessary medical information. Reports are aggregated operational statistics only; this application does not diagnose conditions, recommend treatment, or support real clinical decisions. Before any real deployment, add authentication, role-based access, CSRF protection, audit logging, secure secret management, backups, and appropriate legal/privacy review.


## Updated browser dashboard
The interface now includes a sidebar, overview dashboard, recent visits, searchable visit register, add-visit form, and analytics reports. It remains a local Flask app.

### Windows database setup
Run from this project folder in CMD:

```cmd
mysql -u root -p < schema.sql
```

Set your database settings in the same CMD window (replace the example password):

```cmd
set DB_HOST=localhost
set DB_USER=root
set DB_PASSWORD=YOUR_MYSQL_PASSWORD
set DB_NAME=hospital_analytics
```

Then run `run_windows.bat` or activate `.venv` and run `python app.py`. Open `http://127.0.0.1:5000` in Chrome. Keep the CMD window open. The app is local-only unless you deploy it to a hosting service.
